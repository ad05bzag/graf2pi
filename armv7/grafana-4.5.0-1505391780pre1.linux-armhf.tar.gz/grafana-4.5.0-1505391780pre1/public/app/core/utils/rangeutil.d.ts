/// <reference path="../../../../public/app/headers/common.d.ts" />
export declare function getRelativeTimesList(timepickerSettings: any, currentDisplay: any): any;
export declare function describeTextRange(expr: any): any;
export declare function describeTimeRange(range: any): any;
