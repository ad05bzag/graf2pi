/*! grafana - v4.5.0-1505391780pre1 - 2017-09-14
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

System.register([],function(a,b){"use strict";function c(a,b,c,d){for(var e in c)c.hasOwnProperty(e)&&(a[e]=void 0===b[e]?c[e]:b[e])}b&&b.id;return a("assignModelProperties",c),{setters:[],execute:function(){}}});