/*! grafana - v4.5.0-1505391780pre1 - 2017-09-14
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./alert_srv","./util_srv","./datasource_srv","./context_srv","./timer","./keyboard_manager","./analytics","./popover_srv","./segment_srv","./backend_srv","./dynamic_directive_srv"],function(){});