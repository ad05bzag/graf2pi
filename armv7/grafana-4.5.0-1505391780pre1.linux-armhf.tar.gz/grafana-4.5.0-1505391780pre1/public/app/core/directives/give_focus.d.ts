/// <reference path="../../../../public/app/headers/common.d.ts" />
declare const _default: {};
export default _default;
