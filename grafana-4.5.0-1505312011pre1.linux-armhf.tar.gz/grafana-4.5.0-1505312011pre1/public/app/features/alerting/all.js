/*! grafana - v4.5.0-1505312011pre1 - 2017-09-13
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["./alert_list_ctrl","./notifications_list_ctrl","./notification_edit_ctrl"],function(a,b){"use strict";b&&b.id;return{setters:[function(a){},function(a){},function(a){}],execute:function(){}}});