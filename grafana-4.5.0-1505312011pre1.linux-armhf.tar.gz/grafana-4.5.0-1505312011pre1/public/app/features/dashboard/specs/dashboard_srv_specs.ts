import {describe, beforeEach, it, sinon, expect, angularMocks} from 'test/lib/common';

import {DashboardSrv} from '../dashboard_srv';

describe('dashboardSrv', function() {
  var _dashboardSrv;

  beforeEach(() => {
    _dashboardSrv = new DashboardSrv({}, {}, {});
  });

});
