/*! grafana - v4.5.0-1505312011pre1 - 2017-09-13
 * Copyright (c) 2017 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./panel_menu","./panel_directive","./solo_panel_ctrl","./query_ctrl","./panel_editor_tab","./query_editor_row","./query_troubleshooter"],function(){});