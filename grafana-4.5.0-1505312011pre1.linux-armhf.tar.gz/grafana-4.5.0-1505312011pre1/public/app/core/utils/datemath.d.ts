/// <reference path="../../../../public/app/headers/common.d.ts" />
export declare function parse(text: any, roundUp?: any): any;
export declare function isValid(text: any): any;
export declare function parseDateMath(mathString: any, time: any, roundUp?: any): any;
